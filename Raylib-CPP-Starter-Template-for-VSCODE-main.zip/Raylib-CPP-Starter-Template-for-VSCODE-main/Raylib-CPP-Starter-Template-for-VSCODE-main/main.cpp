#include <iostream>
#include <raylib.h>
#include<vector>
#include<cstdlib>
#include<queue>
#include<unistd.h>
#include<conio.h>
#include<string.h>
using namespace std;
Color red ={255,0,0,250};
Color green ={173,204,96,255};
Color blue ={100,100,100,255};
int score =0;
int size_cell =30;
int amount_cell =25;
bool game_over =false;
double lasttime =0;
bool event(double interval){
    double currentime =GetTime();
    if(currentime-lasttime>=interval){
        lasttime =currentime;
        return true;
    }
    return false;
}

class food{
    
       
       
    public:
        float x,y;
        food(){
            x=7;
            y=7;
        }
       
        void draw(){
            
            DrawRectangle(x*size_cell,y*size_cell,size_cell,size_cell,red);
        }
       

};
class snake{
    private:
        float x,y;
        enum enumerate{stop =0,top,down,left,right};
        enumerate dir;
        deque<Vector2>v ={{5,9},{6,9},{7,9}};
        
    public:
        food t;
        snake(){
            x =(size_cell)*(amount_cell/2);
            y =(size_cell)*(amount_cell/2);

        }
        void draw(){
            for(long long unsigned int i=0;i<v.size();i++){
                x =v[i].x;
                y =v[i].y;
                // float a =v.back().x;
                // float b =v.back().y;
                // v.pop_front();
                // if(b>=30)b=0;
                // // if(y<=0)y=25;
                // v.push_back({float(a),float(b+1)});
              
                // DrawRectangle(x,y,size_cell,size_cell,blue);
                Rectangle segment =Rectangle{x*size_cell,y*size_cell,float(size_cell),float(size_cell)};
                DrawRectangleRounded(segment,0.5,6,blue);
            }
           
        }
        void update(){
                float a =v.front().x;
                float b =v.front().y;
              
               
                switch (dir)
                {
                    case top:
                        b--;
                        break;
                    case down:
                        b++;
                        break;
                    case left:
                        a--;
                        break;
                    case right:
                        a++;
                        break;
                    default:
                        break;
                }
               
                if(b>=30)b=0;
                if(b<0)b=29;
                if(a>=30)a=0;
                if(a<0)a=29;
                
                if(a==t.x&&b==t.y){
                    cout<<t.x<<" "<<t.y<<endl;
                    t.x =rand()%(amount_cell-1);
                    t.y=rand()%(amount_cell-1);
                    score+=10;
                    cout<<t.x<<" "<<t.y<<endl;
                    

                    // t.draw();
                }else{
                    v.pop_back();
                }
                // if(y<=0)y=25;
                v.push_front({a,b});

        }
        void input(){
            while(_kbhit()){
                
                switch (_getch())
                {
                case 'w':
                    dir =top;
                    break;
                case 's':
                    dir =down;
                    break;
                case 'd':
                    dir =right;
                    break;
                case 'a':
                    dir =left;
                    break;
               
                default:
                    break;
                }
            }
            
        }
    

};
int main () {
    InitWindow(size_cell*amount_cell,size_cell*amount_cell,"game_snake");
    SetTargetFPS(60);
    food f;
    snake t;
    
  
    while(WindowShouldClose()==false){
       
        BeginDrawing();
        ClearBackground(green);
        t.t.draw();
        t.draw();
        //t.input();
        // t.update();
        t.input();
        if(event(0.2)){
           
            t.update();
        }
        std::string scorestr =std::to_string(score);

        const char* t =scorestr.c_str();
        DrawText(t,20,20,25,red);
        
        // t.draw();
        // t.input();
        // t.update();
        // t.input();
        
       
        EndDrawing();
        
      
    }
    CloseWindow();
    return 0;
}